package uz.espmod;

/** Simple in-memory toggles for every module. */
public final class Config {
    private Config() {}

    public static boolean fullbright = false;
    public static boolean playerEsp = false;
    public static boolean chestEsp = false;
    public static boolean enderChestEsp = false;
    public static boolean torchEsp = false;
    public static boolean triggerbot = false;
    public static boolean triggerPlayersOnly = false;
    public static boolean autoSprint = false;

    /** Freecam speed in blocks per tick (20 ticks = 1 second). */
    public static double freecamSpeed = 0.6;
}
