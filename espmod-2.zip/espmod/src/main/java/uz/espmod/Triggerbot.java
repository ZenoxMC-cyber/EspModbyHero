package uz.espmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Attacks automatically when the crosshair is on a living entity and the weapon is fully charged. */
public final class Triggerbot {
    private Triggerbot() {}

    public static void tick(MinecraftClient mc) {
        if (!Config.triggerbot) return;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || Freecam.enabled) return;
        if (mc.player.isUsingItem()) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;

        Entity target = entityHit.getEntity();
        if (!(target instanceof LivingEntity living)) return;
        if (!living.isAlive() || target instanceof ArmorStandEntity) return;
        if (Config.triggerPlayersOnly && !(target instanceof PlayerEntity)) return;

        // Wait for the full attack cooldown so every hit does full damage / crits.
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
