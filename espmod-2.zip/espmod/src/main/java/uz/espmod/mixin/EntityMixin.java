package uz.espmod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import uz.espmod.Freecam;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** In freecam the mouse rotates the camera instead of the real player. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void espmod$freecamLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (!Freecam.enabled) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;

        Freecam.yaw += (float) cursorDeltaX * 0.15f;
        Freecam.pitch = MathHelper.clamp(Freecam.pitch + (float) cursorDeltaY * 0.15f, -90.0f, 90.0f);
        ci.cancel();
    }
}
