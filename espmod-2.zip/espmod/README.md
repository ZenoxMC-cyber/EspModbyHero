# ESP Mod (Fabric 1.21.4, client-side)

Features: Fullbright, Player ESP, Chest ESP, Ender Chest ESP, Torch ESP, Triggerbot, Freecam.

## Controls
- **Right Shift** - open the menu (toggle every module with a button)
- **V** - toggle Freecam (rebindable in Options > Controls > ESP Mod)
- Freecam: WASD to fly, Space = up, Shift = down, Sprint = faster, mouse = look

## Build
1. Install JDK 21
2. In this folder run:
   - Windows: `gradlew.bat build`
   - Linux/macOS: `./gradlew build`
3. The jar is in `build/libs/espmod-1.0.0.jar` (not the `-sources` one)
4. Put it in `.minecraft/mods/` together with **Fabric Loader 0.16.10+** and **Fabric API 0.119.2+1.21.4**

## Notes
- Meant for singleplayer / your own server. Most public servers ban these features.
- Written for Yarn mappings `1.21.4+build.8`. If the compiler complains about a renamed method,
  the fix is a one-line rename in the file it points to.

## Build from a phone (GitHub Actions)
1. Create a new repository on github.com, upload the contents of this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, wait for "Build jar" to finish (about 3-5 min).
3. Open the run and download the **espmod-jar** artifact.
