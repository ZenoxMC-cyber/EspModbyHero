package uz.espmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;

/** Settings screen, opened with Right Shift. */
public class MenuScreen extends Screen {
    private int rowY;
    private int colX;

    public MenuScreen() {
        super(Text.literal("ESP Mod"));
    }

    @Override
    protected void init() {
        final int w = 200;
        colX = this.width / 2 - w / 2;
        rowY = this.height / 2 - 105;

        toggle("Fullbright", () -> Config.fullbright, () -> Config.fullbright = !Config.fullbright);
        toggle("Player ESP", () -> Config.playerEsp, () -> Config.playerEsp = !Config.playerEsp);
        toggle("Chest ESP", () -> Config.chestEsp, () -> Config.chestEsp = !Config.chestEsp);
        toggle("Ender Chest ESP", () -> Config.enderChestEsp, () -> Config.enderChestEsp = !Config.enderChestEsp);
        toggle("Torch ESP", () -> Config.torchEsp, () -> Config.torchEsp = !Config.torchEsp);
        toggle("Triggerbot", () -> Config.triggerbot, () -> Config.triggerbot = !Config.triggerbot);
        toggle("Triggerbot: players only", () -> Config.triggerPlayersOnly,
                () -> Config.triggerPlayersOnly = !Config.triggerPlayersOnly);
        toggle("Freecam", () -> Freecam.enabled, () -> Freecam.toggle(this.client));

        rowY += 8;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(colX, rowY, w, 20).build());
    }

    private void toggle(String name, BooleanSupplier state, Runnable action) {
        ButtonWidget button = ButtonWidget.builder(label(name, state.getAsBoolean()), b -> {
            action.run();
            b.setMessage(label(name, state.getAsBoolean()));
        }).dimensions(colX, rowY, 200, 20).build();
        this.addDrawableChild(button);
        rowY += 24;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 125, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
