package uz.espmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class EspModClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding freecamKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.espmod.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.espmod"));
        freecamKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.espmod.freecam", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.espmod"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
            }
            while (freecamKey.wasPressed()) {
                Freecam.toggle(mc);
            }

            Fullbright.tick(mc);
            Freecam.tick(mc);
            Esp.tick(mc);
            Triggerbot.tick(mc);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(Esp::render);

        ClientLifecycleEvents.CLIENT_STOPPING.register(Fullbright::restore);
    }
}
